package com.lti.poc.worker;

import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.VariablesAsType;
import io.camunda.zeebe.spring.common.exception.ZeebeBpmnError;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
public class GenerateReport {

    @JobWorker(type = "generateReport", pollInterval = 1000)
    public Map<String, Object> generateReport(@VariablesAsType Map<String, Object> variables) {

        log.info("Generate Report Worker Class");
        Map<String, Object> updatedProcessVariables = new HashMap<>();

        int retryCount = Integer.parseInt(String.valueOf(variables.getOrDefault("retryCount", "0")));
        String isReportGenerated = String.valueOf(variables.getOrDefault("isReportGenerated", "false"));

        if(retryCount != 0) {
            retryCount = retryCount + 1;
        }

        if(retryCount > 2) {
            isReportGenerated = "fail";
            throw new ZeebeBpmnError("002", "Report Generation is Failed - Flow Stopped ", updatedProcessVariables);
        }

        updatedProcessVariables.put("retryCount", retryCount);
        updatedProcessVariables.put("isReportGenerated", isReportGenerated);

        return updatedProcessVariables;
    }
}
