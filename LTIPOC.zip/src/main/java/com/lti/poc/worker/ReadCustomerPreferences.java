package com.lti.poc.worker;

import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.VariablesAsType;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class ReadCustomerPreferences {

    @JobWorker(type = "readCustomerPreferences", pollInterval = 1000)
    public Map<String, Object> readCustomerPreferences(@VariablesAsType Map<String, Object> variables) {

        String customerId = String.valueOf(variables.getOrDefault("customerId", ""));
        Map<String, Object> updatedVariables = new HashMap<>();
        updatedVariables.put("notificationPreference" , "both");


        return updatedVariables;
    }
}
