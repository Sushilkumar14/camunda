package com.lti.poc.worker;

import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.VariablesAsType;
import io.camunda.zeebe.spring.common.exception.ZeebeBpmnError;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Component
public class PaymentProcessWorker {

    @JobWorker(type = "processMessages", pollInterval = 1000)
    public void processMessages(@VariablesAsType Map<String, Object> variables) {

        boolean stopErrorEvent = Boolean.parseBoolean(String.valueOf(variables.getOrDefault("stopErrorEvent", "")));
        boolean proceed = Boolean.parseBoolean(String.valueOf(variables.getOrDefault("proceed", "")));

        Map<String, Object> updatedProcessVariables = new HashMap<>();

        if(!stopErrorEvent)
            throw new ZeebeBpmnError("001", "processMsgError", variables);

        if(proceed) {
            updatedProcessVariables.put("proceed", "true");
            updatedProcessVariables.put("retryCount", 0);
        } else {
            updatedProcessVariables.put("proceed", "false");
        }

    }
}
