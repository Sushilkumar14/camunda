package com.lti.poc.worker;

import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.VariablesAsType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
public class FailedReport {

    @JobWorker(type = "failedReport", pollInterval = 1000)
    public Map<String, Object> failedReport(@VariablesAsType Map<String, Object> variables) {

        log.info("Report Failed Notified");
        int retryCount = Integer.parseInt(String.valueOf(variables.getOrDefault("retryCount", "0")));
        Map<String, Object> updatedProcessVariables = new HashMap<>();
        retryCount = retryCount + 1;
        updatedProcessVariables.put("retryCount", retryCount);

        return updatedProcessVariables;

    }
}
