package com.lti.poc.worker;

import io.camunda.zeebe.spring.client.annotation.JobWorker;
import io.camunda.zeebe.spring.client.annotation.VariablesAsType;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class ReadMessageTypes {

    @JobWorker(type = "readMessageTypes", pollInterval = 1000)
    public Map<String, Object> readMessageTypes(@VariablesAsType Map<String, Object> variables) {

        List<String> msgTypesList = new ArrayList<>();
        Map<String, Object> updatedProcessVariables = new HashMap<>();

        msgTypesList.add("paymentProcess");
        msgTypesList.add("creditApplication");
        msgTypesList.add("loanApplication");

        updatedProcessVariables.put("msgTypesList",msgTypesList);

        return updatedProcessVariables;
    }
}
