package com.lti.poc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LtipocApplicationTests {

    @Test
    void contextLoads() {
    }

}
